package kosta.springjspblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJspBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
